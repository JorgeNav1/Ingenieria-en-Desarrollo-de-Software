-- Insert cat_centros

insert into cat_centros values (000201, 'Tiendas �ngel flores ropa', 'Culiac�n')
insert into cat_centros values (000202, 'Tiendas �ngel flores muebles', 'Culiac�n')
insert into cat_centros values (000203, 'Tiendas �ngel flores cajas', 'Culiac�n')
insert into cat_centros values (049001, 'La primavera ropa', 'Culiac�n')
insert into cat_centros values (049002, 'La primavera muebles', 'Culiac�n')
insert into cat_centros values (049003, 'La primavera cajas', 'Culiac�n')

-- insert cat_puestos

insert into cat_puestos (nombre_puesto, descripcion_puesto) values ('Gerente de tienda', 'Es responsable de la gesti�n y operaci�n diaria del establecimiento comercial');
insert into cat_puestos (nombre_puesto, descripcion_puesto) values ('Vendedor', 'Encargado de atender al cliente en el punto de venta, asesor�ndolo sobre los productos, manejando el proceso de venta y manteniendo el orden y presentaci�n del local');
insert into cat_puestos (nombre_puesto, descripcion_puesto) values ('Cajero', 'Responsable de procesar transacciones de ventas, manejar efectivo y otros m�todos de pago, y brindar atenci�n al cliente');
insert into cat_puestos (nombre_puesto, descripcion_puesto) values ('Exhibidor', 'esponsable de crear y mantener exhibiciones atractivas y funcionales de productos para maximizar las ventas y mejorar la experiencia del cliente');
insert into cat_puestos (nombre_puesto, descripcion_puesto) values ('Limpieza', 'Responsable de mantener la limpieza y el orden de todas las �reas, tanto internas como externas, para garantizar un ambiente agradable y seguro para clientes y empleados');

-- Insert cat_empleados
select * from cat_empleados

insert into cat_empleados (nombre, apellido_paterno, apellido_materno, fecha_nacimiento, id_centro_trabajo, id_puesto)
values ('Jorge Luis', 'Navidad', 'Lapizco', '1988-04-04', 049001, 1);
insert into cat_empleados (nombre, apellido_paterno, apellido_materno, fecha_nacimiento, id_centro_trabajo, id_puesto)
values ('Luis Enrique', 'Contreras', 'Cordova', '1995-03-24', 049003, 3);
insert into cat_empleados (nombre, apellido_paterno, apellido_materno, fecha_nacimiento, id_centro_trabajo, id_puesto)
values ('Karla Berenice', 'Olea', 'Orpineda', '1990-03-09', 049002, 2);
insert into cat_empleados (nombre, apellido_paterno, apellido_materno, fecha_nacimiento, id_centro_trabajo, id_puesto)
values ('Kevin Tomas', 'Lugo', 'Bojorquez', '2000-10-31', 000201, 4);
insert into cat_empleados (nombre, apellido_paterno, apellido_materno, fecha_nacimiento, id_centro_trabajo, id_puesto)
values ('Armando', 'Ornelas', 'Reatiga', '1999-11-09', 000203, 5);

-- insert cat_directivos

insert into cat_directivos (numero_empleado, numero_centro_supervisa) values (1, 049001);






