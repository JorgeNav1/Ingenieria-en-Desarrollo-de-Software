-- Script para crear la tabla cat_centros
CREATE TABLE cat_centros (
    id_centro INT NOT NULL,
    nombre_centro VARCHAR(50) NOT NULL,
    ciudad VARCHAR(50) NOT NULL,
    CONSTRAINT PK_cat_centros PRIMARY KEY (id_centro)
);

-- Script para crear la tabla cat_puestos
CREATE TABLE cat_puestos (
    id_puesto INT IDENTITY(1,1) NOT NULL,
    nombre_puesto VARCHAR(50) NOT NULL,
    descripcion_puesto VARCHAR(250) UNIQUE,
    CONSTRAINT PK_cat_puestos PRIMARY KEY (id_puesto)
);

-- Script para crear la tabla cat_empleados
CREATE TABLE cat_empleados (
    numero_empleado INT IDENTITY(1,1) NOT NULL,
    nombre VARCHAR(50) NOT NULL,
    apellido_paterno VARCHAR(50) NOT NULL,
    apellido_materno VARCHAR(50) NOT NULL,
    fecha_nacimiento DATE NOT NULL,
    id_centro_trabajo INT NOT NULL,
    id_puesto INT NOT NULL,
    es_directivo BIT DEFAULT 0,
    CONSTRAINT PK_cat_empleados PRIMARY KEY (numero_empleado),
    CONSTRAINT FK_empleados_centros FOREIGN KEY (id_centro_trabajo) REFERENCES cat_centros (id_centro),
    CONSTRAINT FK_empleados_puestos FOREIGN KEY (id_puesto) REFERENCES cat_puestos (id_puesto)
);

-- Script para crear la tabla cat_directivos
CREATE TABLE cat_directivos (
    numero_empleado INT NOT NULL,
    numero_centro_supervisa INT NOT NULL,
    prestacion_combustible BIT DEFAULT 0, 
    CONSTRAINT PK_cat_directivos PRIMARY KEY (numero_empleado),
    CONSTRAINT FK_directivos_empleados FOREIGN KEY (numero_empleado) REFERENCES cat_empleados (numero_empleado),
    CONSTRAINT FK_directivos_centros FOREIGN KEY (numero_centro_supervisa) REFERENCES cat_centros (id_centro)
);