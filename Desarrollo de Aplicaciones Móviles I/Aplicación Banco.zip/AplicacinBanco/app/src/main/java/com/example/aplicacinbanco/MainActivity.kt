package com.example.aplicacinbanco

import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
// === ESTA IMPORTACIÓN ES LA QUE FALTA ===
import com.example.aplicacinbanco.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Corregido: binding.root (no binding.ront)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogin.setOnClickListener {
            val emailIngresado = binding.etEmail.text.toString().trim()
            val passwordIngresada = binding.etPassword.text.toString()

            when {
                emailIngresado != "jjorge_navidad@gmail.com" -> {
                    mostrarModal("Error de usuario", "El correo ingresado no es correcto.")
                }
                passwordIngresada != "123456" -> {
                    mostrarModal("Error de contraseña", "La contraseña ingresada no es correcta.")
                }
                else -> {
                    mostrarModal("Ingreso", "¡Bienvenido!")
                }
            }
        }
    }

    private fun mostrarModal(titulo: String, mensaje: String) {
        AlertDialog.Builder(this)
            .setTitle(titulo)
            .setMessage(mensaje)
            .setPositiveButton("Aceptar") { dialog, _ -> dialog.dismiss() }
            .setCancelable(false)
            .show()
    }
}